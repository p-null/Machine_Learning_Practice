# encoding: utf-8
"""
@author: xyliao
@contact: xyliao1993@qq.com
"""
from .get_submission_result import predict_result
from .test_data import TestSet
